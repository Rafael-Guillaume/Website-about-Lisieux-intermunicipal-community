// Fonctions optimisées et conformes W3C
function togglePopup(popupId, show) {
    const popup = document.getElementById(popupId);
    const overlay = document.getElementById('popupOverlay');
    
    if (!popup || !overlay) {
        console.error('Élément popup ou overlay introuvable');
        return;
    }
    
    if (show) {
        popup.classList.add('active');
        overlay.classList.add('active');
    } else {
        popup.classList.remove('active');
        overlay.classList.remove('active');
    }
}

function openCitizenPopup() {
    togglePopup('citizenPopup', true);
}

function closeCitizenPopup() {
    togglePopup('citizenPopup', false);
}

function openMunicipalPopup() {
    togglePopup('municipalPopup', true);
}

function closeMunicipalPopup() {
    togglePopup('municipalPopup', false);
}

function closeAllPopups() {
    const overlay = document.getElementById('popupOverlay');
    const popups = document.querySelectorAll('.popup, [id$="Popup"]');
    
    if (overlay) {
        overlay.classList.remove('active');
    }
    
    popups.forEach(function(popup) {
        popup.classList.remove('active');
    });
}